import { Component, OnInit } from '@angular/core';
import { _user } from '../interface/user.interface';
import { NgForm } from '@angular/forms';


@Component({
  selector: 'app-login',
  template: `
    <div class="container mt-4">
      <form class="card card-body mt-3"    #f="ngForm"  (submit)="logUser(f)">
        <!--Username-->
        <label for="username">Username</label>
        <input type="text" placeholder="Username" [ngModel]  #usernameInput="ngModel" name="username" required [ngClass]="{'is-invalid': usernameInput.invalid && f.dirty}"/>
        <!--Password-->
        <label for="password">Password</label>
        <input type="password" placeholder="Password" name="password" [ngModel]  #passwordInput="ngModel" required [ngClass]="{'is-invalid': passwordInput.invalid && f.dirty}"/>
        <!--Button-->
        <button class="btn btn-primary ml-2"  [disabled]="f.invalid">Login</button>
      </form>

      <div class="container mt-4">
        <div *ngFor="let u of User" class="list-group-item">
          <p>Username : {{ u.username }} Password: {{ u.password }}</p>
        </div>
      </div>
    </div>
  `,
  styles: [],
})
export class LoginComponent implements OnInit {
  User: _user[] = [];

  constructor() {
    this.User = [
      { username: 'Giacomo', password: '0000' },
      { username: 'Gianluca', password: '1111' },
      { username: 'Mattia', password: '2222' },
    ];
  }

  logUser(f:NgForm){
    const Us = f.value as _user;
    this.User=[...this.User,Us]
    f.reset();

  }

  ngOnInit(): void {}
}
