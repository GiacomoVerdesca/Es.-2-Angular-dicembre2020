export interface _user {
  username:string,
  password:string

}
