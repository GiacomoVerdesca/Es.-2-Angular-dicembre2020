import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-contatti',
  template: `
  <p>Contatti</p>

  `,
  styles: [
  ]
})
export class ContattiComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
