import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { NgForm } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { LoginComponent } from './features/login/login.component';
import { CatalogComponent } from './features/catalog/catalog.component';
import { UsersComponent } from './features/users/users.component';
import { NavbarComponent } from './core/navbar/navbar.component';
import { ContattiComponent } from './features/contatti/contatti.component';
import { Error404Component } from './features/error404/error404.component';
import { FormsModule } from '@angular/forms';

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent,
    CatalogComponent,
    UsersComponent,
    NavbarComponent,
    ContattiComponent,
    Error404Component,
    FormsModule,
    NgForm

  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
