import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './features/login/login.component';
import { CatalogComponent } from './features/catalog/catalog.component';
import { UsersComponent } from './features/users/users.component';
import{ContattiComponent}from './features/contatti/contatti.component';
import{Error404Component} from './features/error404/error404.component';




const routes: Routes = [
  { path: 'catalog', component: CatalogComponent },
  { path: 'users', component: UsersComponent },
  { path: 'contatti', component: ContattiComponent },
  { path: '', component: LoginComponent },
  { path: '404', component: Error404Component },
  { path: '**', redirectTo: '404' },

];

@NgModule({
  imports: [RouterModule.forRoot(routes),
    ],
  exports: [RouterModule]
})
export class AppRoutingModule { }
