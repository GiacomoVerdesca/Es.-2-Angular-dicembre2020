import { Component} from '@angular/core';


@Component({
  selector: 'app-navbar',
  template: `
    <button routerLink="/" class="btn btn-primary">Login</button>
    <button routerLink="catalog" class="btn btn-primary">Catalog</button>
    <button routerLink="users" class="btn btn-primary">Users</button>
    <button routerLink="contatti" class="btn btn-primary">Contatti</button>
  `,
  styles: [],
})
export class NavbarComponent  {
  constructor() {}

  ngOnInit(): void {}
}
